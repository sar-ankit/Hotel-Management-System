# Healthcare Backend API

A comprehensive healthcare backend system built with Node.js, Express.js, and PostgreSQL. This system provides secure user authentication and management of patient and doctor records with proper relationships.

## Features

- 🔐 JWT-based authentication
- 👥 User registration and login
- 🏥 Patient management (CRUD operations)
- 👨‍⚕️ Doctor management (CRUD operations)
- 🔗 Patient-Doctor mapping system
- 📊 Pagination and search functionality
- ✅ Input validation with Joi
- 🛡️ Security middleware (Helmet, CORS, Rate Limiting)
- 🗄️ PostgreSQL database with Sequelize ORM

## Tech Stack

- **Backend**: Node.js, Express.js
- **Database**: PostgreSQL
- **ORM**: Sequelize
- **Authentication**: JWT (JSON Web Tokens)
- **Validation**: Joi
- **Security**: Helmet, CORS, bcryptjs
- **Environment**: dotenv

## Prerequisites

- Node.js (v16 or higher)
- PostgreSQL (v12 or higher)
- npm or yarn

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd healthcare-backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Update the `.env` file with your database credentials and JWT secret:
   ```env
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=healthcare_db
   DB_USER=your_username
   DB_PASSWORD=your_password
   JWT_SECRET=your_super_secret_jwt_key
   JWT_EXPIRES_IN=7d
   PORT=3000
   NODE_ENV=development
   ```

4. **Create PostgreSQL database**
   ```sql
   CREATE DATABASE healthcare_db;
   ```

5. **Start the server**
   ```bash
   # Development mode with auto-restart
   npm run dev
   
   # Production mode
   npm start
   ```

The server will start on `http://localhost:3000`

## API Endpoints

### Authentication

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/register` | Register new user | No |
| POST | `/api/auth/login` | Login user | No |

### Patients

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/patients` | Create new patient | Yes |
| GET | `/api/patients` | Get all patients (user's own) | Yes |
| GET | `/api/patients/:id` | Get specific patient | Yes |
| PUT | `/api/patients/:id` | Update patient | Yes |
| DELETE | `/api/patients/:id` | Delete patient | Yes |

### Doctors

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/doctors` | Create new doctor | Yes |
| GET | `/api/doctors` | Get all doctors | Yes |
| GET | `/api/doctors/:id` | Get specific doctor | Yes |
| PUT | `/api/doctors/:id` | Update doctor | Yes |
| DELETE | `/api/doctors/:id` | Delete doctor | Yes |

### Patient-Doctor Mappings

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/mappings` | Assign doctor to patient | Yes |
| GET | `/api/mappings` | Get all mappings | Yes |
| GET | `/api/mappings/:patientId` | Get doctors for patient | Yes |
| DELETE | `/api/mappings/:id` | Remove doctor from patient | Yes |

## Request Examples

### Register User
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "password": "password123"
  }'
```

### Login User
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'
```

### Create Patient
```bash
curl -X POST http://localhost:3000/api/patients \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "firstName": "Jane",
    "lastName": "Smith",
    "email": "jane.smith@example.com",
    "phone": "+1234567890",
    "dateOfBirth": "1990-05-15",
    "gender": "female",
    "address": "123 Main St, City, State",
    "medicalHistory": "No known allergies",
    "emergencyContact": "+1987654321"
  }'
```

### Create Doctor
```bash
curl -X POST http://localhost:3000/api/doctors \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "firstName": "Dr. Michael",
    "lastName": "Johnson",
    "email": "dr.johnson@hospital.com",
    "phone": "+1555123456",
    "specialization": "Cardiology",
    "licenseNumber": "MD123456",
    "experience": 10,
    "qualification": "MD, FACC",
    "department": "Cardiology",
    "consultationFee": 200.00,
    "availability": {
      "monday": "9:00-17:00",
      "tuesday": "9:00-17:00",
      "wednesday": "9:00-17:00"
    }
  }'
```

### Assign Doctor to Patient
```bash
curl -X POST http://localhost:3000/api/mappings \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "patientId": "patient-uuid-here",
    "doctorId": "doctor-uuid-here",
    "notes": "Regular checkup appointment"
  }'
```

## Database Schema

### Users Table
- `id` (UUID, Primary Key)
- `name` (String, Required)
- `email` (String, Unique, Required)
- `password` (String, Hashed, Required)
- `createdAt`, `updatedAt` (Timestamps)

### Patients Table
- `id` (UUID, Primary Key)
- `firstName`, `lastName` (String, Required)
- `email` (String, Required)
- `phone` (String, Required)
- `dateOfBirth` (Date, Required)
- `gender` (Enum: male/female/other, Required)
- `address` (Text, Optional)
- `medicalHistory` (Text, Optional)
- `emergencyContact` (String, Optional)
- `createdBy` (UUID, Foreign Key to Users)
- `createdAt`, `updatedAt` (Timestamps)

### Doctors Table
- `id` (UUID, Primary Key)
- `firstName`, `lastName` (String, Required)
- `email` (String, Unique, Required)
- `phone` (String, Required)
- `specialization` (String, Required)
- `licenseNumber` (String, Unique, Required)
- `experience` (Integer, Required)
- `qualification` (String, Required)
- `department` (String, Required)
- `consultationFee` (Decimal, Required)
- `availability` (JSON, Optional)
- `createdAt`, `updatedAt` (Timestamps)

### Patient-Doctor Mappings Table
- `id` (UUID, Primary Key)
- `patientId` (UUID, Foreign Key to Patients)
- `doctorId` (UUID, Foreign Key to Doctors)
- `assignedDate` (Date, Default: Now)
- `status` (Enum: active/inactive/completed)
- `notes` (Text, Optional)
- `createdAt`, `updatedAt` (Timestamps)

## Security Features

- **Password Hashing**: bcryptjs with salt rounds
- **JWT Authentication**: Secure token-based authentication
- **Rate Limiting**: Prevents API abuse
- **CORS**: Cross-origin resource sharing configuration
- **Helmet**: Security headers
- **Input Validation**: Joi schema validation
- **SQL Injection Protection**: Sequelize ORM parameterized queries

## Error Handling

The API includes comprehensive error handling for:
- Validation errors
- Authentication errors
- Database constraint violations
- Not found errors
- Server errors

All errors return consistent JSON responses with appropriate HTTP status codes.

## Testing

You can test the API endpoints using:
- **Postman**: Import the collection (create one based on the endpoints above)
- **curl**: Use the command examples provided
- **Thunder Client**: VS Code extension for API testing

## Development

### Project Structure
```
healthcare-backend/
├── config/
│   └── database.js          # Database configuration
├── middleware/
│   ├── auth.js             # Authentication middleware
│   ├── errorHandler.js     # Global error handler
│   └── validation.js       # Request validation
├── models/
│   ├── User.js             # User model
│   ├── Patient.js          # Patient model
│   ├── Doctor.js           # Doctor model
│   ├── PatientDoctorMapping.js # Mapping model
│   └── index.js            # Model associations
├── routes/
│   ├── auth.js             # Authentication routes
│   ├── patients.js         # Patient routes
│   ├── doctors.js          # Doctor routes
│   └── mappings.js         # Mapping routes
├── .env                    # Environment variables
├── .env.example            # Environment template
├── server.js               # Main server file
└── README.md               # This file
```

### Adding New Features

1. Create new models in `models/` directory
2. Add routes in `routes/` directory
3. Implement validation schemas in `middleware/validation.js`
4. Update associations in `models/index.js`
5. Test endpoints thoroughly

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the ISC License.