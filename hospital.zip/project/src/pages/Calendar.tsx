import React from 'react';
import { Calendar as CalendarIcon, Clock, Plus } from 'lucide-react';
import { mockEvents } from '../utils/data';

const Calendar: React.FC = () => {
  const today = new Date();
  const upcomingEvents = mockEvents.filter(event => 
    new Date(event.date) >= today
  ).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const eventTypeColors = {
    meeting: 'bg-blue-100 text-blue-700 border-blue-200',
    deadline: 'bg-red-100 text-red-700 border-red-200',
    reminder: 'bg-amber-100 text-amber-700 border-amber-200'
  };

  const eventTypeIcons = {
    meeting: '👥',
    deadline: '⏰',
    reminder: '🔔'
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Calendar</h1>
          <p className="text-gray-600">Manage your schedule and events</p>
        </div>
        <button className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors duration-200">
          <Plus className="w-4 h-4" />
          <span>New Event</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar View */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">January 2024</h2>
              <div className="flex space-x-2">
                <button className="px-3 py-1 text-sm text-gray-600 hover:text-gray-900">Previous</button>
                <button className="px-3 py-1 text-sm text-gray-600 hover:text-gray-900">Next</button>
              </div>
            </div>
            
            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-1 mb-4">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="p-3 text-center text-sm font-medium text-gray-500">
                  {day}
                </div>
              ))}
              {Array.from({ length: 35 }, (_, i) => {
                const date = i - 6 + 1;
                const isToday = date === today.getDate();
                const hasEvent = mockEvents.some(event => 
                  new Date(event.date).getDate() === date
                );
                
                return (
                  <div
                    key={i}
                    className={`p-3 text-center text-sm cursor-pointer hover:bg-gray-50 relative ${
                      isToday ? 'bg-indigo-100 text-indigo-600 font-semibold' : ''
                    } ${date < 1 || date > 31 ? 'text-gray-300' : 'text-gray-700'}`}
                  >
                    {date > 0 && date <= 31 ? date : ''}
                    {hasEvent && (
                      <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-indigo-500 rounded-full"></div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Upcoming Events */}
        <div>
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Upcoming Events</h2>
            <div className="space-y-4">
              {upcomingEvents.map(event => (
                <div
                  key={event.id}
                  className={`p-4 rounded-lg border ${eventTypeColors[event.type]}`}
                >
                  <div className="flex items-start space-x-3">
                    <span className="text-lg">{eventTypeIcons[event.type]}</span>
                    <div className="flex-1">
                      <h3 className="font-semibold text-sm">{event.title}</h3>
                      <div className="flex items-center space-x-4 mt-2 text-xs">
                        <div className="flex items-center space-x-1">
                          <CalendarIcon className="w-3 h-3" />
                          <span>{new Date(event.date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{event.time}</span>
                        </div>
                      </div>
                      {event.description && (
                        <p className="text-xs mt-2 opacity-80">{event.description}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Today's Schedule */}
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white mt-6">
            <h3 className="font-semibold mb-3">Today's Schedule</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Team Standup</span>
                <span>9:00 AM</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Code Review</span>
                <span>3:30 PM</span>
              </div>
              <div className="flex justify-between text-sm opacity-75">
                <span>No more events</span>
                <span>—</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calendar;