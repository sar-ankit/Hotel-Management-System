import React from 'react';
import StatsCard from '../components/StatsCard';
import TaskCard from '../components/TaskCard';
import ProjectCard from '../components/ProjectCard';
import { 
  CheckSquare, 
  Clock, 
  TrendingUp, 
  Users,
  Plus,
  ArrowRight
} from 'lucide-react';
import { mockTasks, mockProjects } from '../utils/data';
import { Task } from '../types';

interface DashboardProps {
  tasks: Task[];
  onTaskStatusChange: (taskId: string, newStatus: Task['status']) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ tasks, onTaskStatusChange }) => {
  const completedTasks = tasks.filter(task => task.status === 'completed').length;
  const inProgressTasks = tasks.filter(task => task.status === 'in-progress').length;
  const totalTasks = tasks.length;
  const completionRate = Math.round((completedTasks / totalTasks) * 100);

  const recentTasks = tasks.slice(0, 3);
  const activeProjects = mockProjects.filter(project => project.status === 'active').slice(0, 2);

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Good morning, Sarah! 👋</h1>
            <p className="text-indigo-100 text-lg">
              You have {inProgressTasks} tasks in progress and {completedTasks} completed today.
            </p>
          </div>
          <div className="hidden md:block">
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
              <div className="text-2xl font-bold">{completionRate}%</div>
              <div className="text-sm text-indigo-100">Completion Rate</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Tasks"
          value={totalTasks}
          change="+12% from last week"
          changeType="positive"
          icon={CheckSquare}
          iconColor="bg-indigo-500"
        />
        <StatsCard
          title="In Progress"
          value={inProgressTasks}
          change="+5% from yesterday"
          changeType="positive"
          icon={Clock}
          iconColor="bg-amber-500"
        />
        <StatsCard
          title="Completed"
          value={completedTasks}
          change="+23% from last week"
          changeType="positive"
          icon={TrendingUp}
          iconColor="bg-emerald-500"
        />
        <StatsCard
          title="Team Members"
          value="12"
          change="2 new this month"
          changeType="neutral"
          icon={Users}
          iconColor="bg-purple-500"
        />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Tasks */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Recent Tasks</h2>
              <button className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-700 transition-colors duration-200">
                <span className="text-sm font-medium">View all</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-4">
              {recentTasks.map(task => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onStatusChange={onTaskStatusChange}
                />
              ))}
            </div>
            <button className="w-full mt-4 flex items-center justify-center space-x-2 py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-indigo-300 hover:text-indigo-600 transition-all duration-200">
              <Plus className="w-4 h-4" />
              <span className="font-medium">Add new task</span>
            </button>
          </div>
        </div>

        {/* Active Projects */}
        <div>
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Active Projects</h2>
              <button className="text-indigo-600 hover:text-indigo-700 transition-colors duration-200">
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-4">
              {activeProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6 rounded-xl hover:from-indigo-600 hover:to-purple-700 transition-all duration-200 transform hover:-translate-y-1">
          <div className="flex items-center space-x-3">
            <Plus className="w-6 h-6" />
            <span className="font-semibold">Create New Task</span>
          </div>
        </button>
        <button className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-6 rounded-xl hover:from-emerald-600 hover:to-teal-700 transition-all duration-200 transform hover:-translate-y-1">
          <div className="flex items-center space-x-3">
            <Users className="w-6 h-6" />
            <span className="font-semibold">Invite Team Member</span>
          </div>
        </button>
        <button className="bg-gradient-to-r from-amber-500 to-orange-600 text-white p-6 rounded-xl hover:from-amber-600 hover:to-orange-700 transition-all duration-200 transform hover:-translate-y-1">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-6 h-6" />
            <span className="font-semibold">View Analytics</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default Dashboard;