import { Task, Project, Event, User } from '../types';

export const mockUser: User = {
  id: '1',
  name: 'Sarah Chen',
  email: 'sarah.chen@company.com',
  avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
  role: 'Product Manager'
};

export const mockTasks: Task[] = [
  {
    id: '1',
    title: 'Design System Updates',
    description: 'Update the design system with new color palette and typography',
    status: 'in-progress',
    priority: 'high',
    dueDate: '2024-01-15',
    project: 'Design System',
    assignee: 'Sarah Chen'
  },
  {
    id: '2',
    title: 'User Research Analysis',
    description: 'Analyze user feedback from the latest survey',
    status: 'todo',
    priority: 'medium',
    dueDate: '2024-01-20',
    project: 'Research',
    assignee: 'Mike Johnson'
  },
  {
    id: '3',
    title: 'Sprint Planning',
    description: 'Plan tasks for the upcoming sprint',
    status: 'completed',
    priority: 'high',
    dueDate: '2024-01-10',
    project: 'Planning',
    assignee: 'Sarah Chen'
  },
  {
    id: '4',
    title: 'API Documentation',
    description: 'Update API documentation for v2.0',
    status: 'todo',
    priority: 'low',
    dueDate: '2024-01-25',
    project: 'Documentation',
    assignee: 'Alex Rivera'
  }
];

export const mockProjects: Project[] = [
  {
    id: '1',
    name: 'Design System',
    description: 'Comprehensive design system for all products',
    progress: 75,
    status: 'active',
    dueDate: '2024-02-01',
    team: ['Sarah Chen', 'Mike Johnson', 'Emma Davis'],
    color: '#6366f1'
  },
  {
    id: '2',
    name: 'Mobile App Redesign',
    description: 'Complete redesign of the mobile application',
    progress: 45,
    status: 'active',
    dueDate: '2024-03-15',
    team: ['Alex Rivera', 'Sarah Chen'],
    color: '#10b981'
  },
  {
    id: '3',
    name: 'User Research Study',
    description: 'Comprehensive user research for new features',
    progress: 90,
    status: 'active',
    dueDate: '2024-01-30',
    team: ['Mike Johnson', 'Emma Davis'],
    color: '#f59e0b'
  },
  {
    id: '4',
    name: 'Platform Migration',
    description: 'Migrate to new cloud infrastructure',
    progress: 100,
    status: 'completed',
    dueDate: '2024-01-05',
    team: ['Alex Rivera', 'Tom Wilson'],
    color: '#8b5cf6'
  }
];

export const mockEvents: Event[] = [
  {
    id: '1',
    title: 'Team Standup',
    date: '2024-01-15',
    time: '09:00',
    type: 'meeting',
    description: 'Daily team standup meeting'
  },
  {
    id: '2',
    title: 'Project Deadline',
    date: '2024-01-20',
    time: '17:00',
    type: 'deadline',
    description: 'Design system project deadline'
  },
  {
    id: '3',
    title: 'Client Presentation',
    date: '2024-01-18',
    time: '14:00',
    type: 'meeting',
    description: 'Present progress to client stakeholders'
  },
  {
    id: '4',
    title: 'Code Review',
    date: '2024-01-16',
    time: '15:30',
    type: 'reminder',
    description: 'Review pull requests from the team'
  }
];